# Active process status

Snapshot UTC: $captured. GUI/diagnostic safe: **False**.

The first audit check found an externally owned Method-B seed-47 / 100 mm final development evaluation at local timestep 76,800. It was not interrupted. By the final snapshot, supervisor attempt 3 had advanced to Method-C seed-11 / 50 mm training.

Current Method C state: $(@{arguments=; failures=System.Object[]; height_mm=50; method=C; method_name=with_com; provenance=; run_dir=C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\ppo_with_com\training\method-C-v34_seed-11_stage-50mm_attempt001; schema=resume_validation.residual_ppo_training.v1; seed=11; started_unix=1785533557.4834683; status=RUNNING; training_budget=}.status); observed local timestep 14528 of 76800; 10 checkpoint files; no development gate. This is an in-progress state, not a performance result.

Supervisor: attempt 3, status $(@{schema=resume_validation.full_pipeline_supervisor.v1; updated_utc=2026-07-31T22:04:03.0127650Z; supervisor_pid=61792; attempt=3; status=RUNNING_PIPELINE; message=The recoverable state machine is running; no second invocation is allowed.; runtime_version=v34; locked_test_access=delegated only to run_until_success after verified method freeze; runner_pid=60564; stderr_log=C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\orchestration\full_pipeline_attempt003_runner001.stderr.log; stdout_log=C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\orchestration\full_pipeline_attempt003_runner001.stdout.log; live_training_pids=System.Object[]; runner_invocation=1}.status), updated $(@{schema=resume_validation.full_pipeline_supervisor.v1; updated_utc=2026-07-31T22:04:03.0127650Z; supervisor_pid=61792; attempt=3; status=RUNNING_PIPELINE; message=The recoverable state machine is running; no second invocation is allowed.; runtime_version=v34; locked_test_access=delegated only to run_until_success after verified method freeze; runner_pid=60564; stderr_log=C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\orchestration\full_pipeline_attempt003_runner001.stderr.log; stdout_log=C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\orchestration\full_pipeline_attempt003_runner001.stdout.log; live_training_pids=System.Object[]; runner_invocation=1}.updated_utc).

## Active processes

| PID | Parent | Name | Created UTC | CPU s | Working set bytes | Responding |
|---:|---:|---|---|---:|---:|---|
| 42768 | 127120 | python.exe | 2026-07-31T21:32:28.4713840Z | 0.65625 | 77873152 | True |
| 127120 | 98680 | conda.exe | 2026-07-31T21:32:28.4541850Z | 0 | 8585216 | True |
| 46136 | 67844 | powershell.exe | 2026-07-31T22:03:35.8296030Z | 0.328125 | 88227840 | True |
| 27820 | 6428 | python.exe | 2026-07-31T21:32:30.3758130Z | 1980.03125 | 3932094464 | True |
| 98680 | 89240 | cmd.exe | 2026-07-31T21:32:28.4159090Z | 0 | 9404416 | True |
| 138404 | 43916 | powershell.exe | 2026-07-31T21:32:26.0439950Z | 1.578125 | 92360704 | True |
| 61792 | 43916 | powershell.exe | 2026-07-31T21:32:26.0132430Z | 3.875 | 151150592 | True |
| 89240 | 60564 | powershell.exe | 2026-07-31T21:32:28.1793390Z | 0.28125 | 79302656 | True |
| 60564 | 61792 | powershell.exe | 2026-07-31T21:32:27.5603500Z | 0.765625 | 97873920 | True |

Full command lines (also preserved as structured fields in `active_processes.json`):

- PID 42768: `C:\Users\kskzz\miniconda3\python.exe C:\Users\kskzz\miniconda3\Scripts\conda-script.py run --no-capture-output -n env_isaaclab .\isaaclab.bat -p C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\src\resume_validation\train_residual_ppo.py --method C --seed 11 --height_mm 50 --iterations 1200 --num_envs 64 --rollouts 64 --randomization_level full --run_name method-C-v34_seed-11_stage-50mm_attempt001 --output_root C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\ppo_with_com\training --headless`

- PID 127120: `"C:\Users\kskzz\miniconda3\Scripts\conda.exe"    run --no-capture-output -n env_isaaclab .\isaaclab.bat -p C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\src\resume_validation\train_residual_ppo.py --method C --seed 11 --height_mm 50 --iterations 1200 --num_envs 64 --rollouts 64 --randomization_level full --run_name method-C-v34_seed-11_stage-50mm_attempt001 --output_root C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\ppo_with_com\training --headless`

- PID 46136: `"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -Command "try { [Console]::OutputEncoding=[System.Text.Encoding]::UTF8 } catch {}
Start-Sleep -Seconds 50
$checkpointDir='runs\ppo_with_com\training\method-C-v34_seed-11_stage-50mm_attempt001\checkpoints';$steps=@(Get-ChildItem -LiteralPath $checkpointDir -File -Filter 'agent_*.pt'|ForEach-Object{if($_.BaseName-match'^agent_(\d+)$'){[int]$Matches[1]}}|Sort-Object);[ordered]@{observed_utc=(Get-Date).ToUniversalTime().ToString('o');latest=$steps[-1];count=$steps.Count;trainer_alive=@(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue|Where-Object{$_.Name-eq'python.exe'-and$_.CommandLine-like'*method-C-v34_seed-11_stage-50mm_attempt001*'-and$_.CommandLine-like'*train_residual_ppo.py*'}).Count-gt0}|ConvertTo-Json"`

- PID 27820: `C:\Users\kskzz\miniconda3\envs\env_isaaclab\python.exe  C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\src\resume_validation\train_residual_ppo.py --method C --seed 11 --height_mm 50 --iterations 1200 --num_envs 64 --rollouts 64 --randomization_level full --run_name method-C-v34_seed-11_stage-50mm_attempt001 --output_root C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\ppo_with_com\training --headless`

- PID 98680: `C:\WINDOWS\system32\cmd.exe /c ""C:\Users\kskzz\miniconda3\Library\bin\conda.bat" run --no-capture-output -n env_isaaclab .\isaaclab.bat -p C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\src\resume_validation\train_residual_ppo.py --method C --seed 11 --height_mm 50 --iterations 1200 --num_envs 64 --rollouts 64 --randomization_level full --run_name method-C-v34_seed-11_stage-50mm_attempt001 --output_root C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\runs\ppo_with_com\training --headless"`

- PID 138404: `"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\scripts\pipeline_keep_awake.ps1 -SupervisorPid 61792 -Attempt 4 -PollSeconds 30 `

- PID 61792: `"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\scripts\full_pipeline_supervisor.ps1 -Attempt 3 -PollSeconds 30 -RuntimeVersion v34 -ValidationAttempt 1 -VideoSmokeAttempt 1 -LockedAttempt 1 -VideoAttempt 1 `

- PID 89240: `"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\scripts\06_train_C.ps1 -Attempt 1 -RuntimeVersion v34 -StartSeed 11 -StartHeight 50 -ContinueAfterFailedGate`

- PID 60564: `"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File C:\robotics_sim\wlr_robot\resume_validation_fsm_residual_ppo\scripts\run_until_success.ps1 -RuntimeVersion v34 -ValidationAttempt 1 -VideoSmokeAttempt 1 -LockedAttempt 1 -VideoAttempt 1 `

No process was terminated, suspended, reprioritized, or otherwise modified. No GUI, evaluation, training, validation, or locked test was started by this audit.
